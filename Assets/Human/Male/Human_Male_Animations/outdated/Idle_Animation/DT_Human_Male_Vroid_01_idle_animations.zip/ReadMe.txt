- There is no mesh, textures and etc. in this file
- There is only Bone Animation Data

Animations provided:
- idle animation v1
- idle animation v2
- Combat idle animation
- Combat idle to Idle Animation(transition) 


