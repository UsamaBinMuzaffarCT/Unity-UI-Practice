- There is no mesh, textures and etc. in this file
- There is only Bone Animation Data

Animations provided:

- Dive Start
- Swim v1
- Swim v2
- Swim Backwards
- Roll
- Run
- Crouch idle
- Crouch Walk
- Clim Ascend



