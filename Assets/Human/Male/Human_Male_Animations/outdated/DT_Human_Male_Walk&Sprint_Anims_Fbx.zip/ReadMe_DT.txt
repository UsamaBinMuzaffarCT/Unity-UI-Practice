- There is no mesh, textures and etc. in this file
- There is only Bone Animation Data

Animations provided:
- DT_Human_Male - Run V1 - 1H Sword
- DT_Human_Male - Run V2 - 1H Sword
- DT_Human_Male - Sprint - without weapon
- DT_Human_Male - Walk - 1H Sword
- DT_Human_Male - Walk - Without Weapon

